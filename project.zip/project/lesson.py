import numpy


year_of_birth = int(input("Enter the year of birth      "))
current_year = int(input("Enter current year        "))

age = current_year - year_of_birth
if age < 18:
    print ("Get the fuck outta here")
else:
    print("Bossu")
print (age)